//
//  ModelOfDataForTable.swift
//  HW18
//
//  Created by Дмитрий Цветков on 22.10.2022.
//

import Foundation

struct ModelOfDataForTable {
    let cars = ["BMW", "Mercedes", "Lamborghini", "Toyota"] 
    let picture: [String?] = ["BMW", "Mercedes", "Lamborghini", "Toyota", "nil"]
}
