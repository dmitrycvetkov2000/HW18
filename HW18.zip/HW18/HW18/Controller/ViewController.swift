//
//  ViewController.swift
//  HW18
//
//  Created by Дмитрий Цветков on 22.10.2022.
//


import UIKit

class ViewController: UIViewController {

    var modelOfDataForTable = ModelOfDataForTable()


    var myTableView = UITableView()
    let identifier = "myCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()


        myTableView = UITableView(frame: view.bounds, style: .plain)
        myTableView.register(CustomTableViewCell.self, forCellReuseIdentifier: self.identifier)
        
        myTableView.delegate = self
        myTableView.dataSource = self

        view.addSubview(self.myTableView)
        
    }

}
extension ViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modelOfDataForTable.cars.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.identifier, for: indexPath) as? CustomTableViewCell

        if modelOfDataForTable.picture.count > indexPath.row {
            if let pictureOfCar = modelOfDataForTable.picture[indexPath.row]{
                cell?.setImage(image: pictureOfCar)
            }
        }
        cell?.setNameOfCar(name: modelOfDataForTable.cars[indexPath.row])

        return cell ?? CustomTableViewCell()
    }

}


extension ViewController: UITableViewDelegate {
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

            let detailVC = DetailViewController()
            detailVC.nameOfCar = modelOfDataForTable.cars[indexPath.row]

            if modelOfDataForTable.picture.count > indexPath.row {
                if let pictureOfCar = modelOfDataForTable.picture[indexPath.row]{
                    detailVC.pictureName = pictureOfCar
                }
            }
            self.present(detailVC, animated: true)
        }
}

