//
//  DetailViewController.swift
//  HW18
//
//  Created by Дмитрий Цветков on 22.10.2022.
//

import UIKit

class DetailViewController: UIViewController {
    
    var picture = UIImageView()
    var pictureName: String?
    
    var nameOfCarLabel = UILabel()
    var nameOfCar: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(picture)
        view.addSubview(nameOfCarLabel)

        view.backgroundColor = .green
        
        
        picture.translatesAutoresizingMaskIntoConstraints = false

        picture.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        picture.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        picture.widthAnchor.constraint(equalToConstant: 100).isActive = true
        picture.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        picture.image = UIImage(named: pictureName ?? "BMW")
        
        nameOfCarLabel.translatesAutoresizingMaskIntoConstraints = false
        nameOfCarLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true

        nameOfCarLabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
        nameOfCarLabel.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        nameOfCarLabel.topAnchor.constraint(equalTo: picture.bottomAnchor, constant: 8).isActive = true

        nameOfCarLabel.text = nameOfCar
        nameOfCarLabel.textColor = .black
        nameOfCarLabel.textAlignment = .center
    }
}
