//
//  CustomTableViewCell.swift
//  HW18
//
//  Created by Дмитрий Цветков on 22.10.2022.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    let modelOfDataForTable = ModelOfDataForTable()
    
    var nameCarLabel = UILabel()
    var pictureOfCar = UIImageView()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.addSubview(nameCarLabel)
        self.addSubview(pictureOfCar)
        

        
        pictureOfCar.translatesAutoresizingMaskIntoConstraints = false

        pictureOfCar.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8).isActive = true
        pictureOfCar.widthAnchor.constraint(equalToConstant: 80).isActive = true
        pictureOfCar.heightAnchor.constraint(equalToConstant: 80).isActive = true
        pictureOfCar.topAnchor.constraint(equalTo: self.topAnchor, constant: 8).isActive = true
        pictureOfCar.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -8).isActive = true
        
        nameCarLabel.translatesAutoresizingMaskIntoConstraints = false
        
        nameCarLabel.leftAnchor.constraint(equalTo: pictureOfCar.rightAnchor, constant: 12).isActive = true
        nameCarLabel.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0).isActive = true
        nameCarLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 8).isActive = true
        nameCarLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 8).isActive = true
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setImage(image: String) {
        pictureOfCar.image = UIImage(named: image)
    }
    func setNameOfCar(name: String){
        nameCarLabel.text = name
    }
    
}
